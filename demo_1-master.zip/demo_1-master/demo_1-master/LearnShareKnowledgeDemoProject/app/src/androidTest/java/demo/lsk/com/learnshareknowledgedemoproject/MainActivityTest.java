package demo.lsk.com.learnshareknowledgedemoproject;

import junit.framework.TestCase;

/**
 * Created by 310124463 on 6/29/2016.
 */
public class MainActivityTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();

    }

    public void tearDown() throws Exception {

    }

    public void testOnCreate() throws Exception {

        assertTrue(true);

    }

    public void testOnCreateOptionsMenu() throws Exception {

    }

    public void testOnOptionsItemSelected() throws Exception {

    }
}